package config

import (
    "database/sql"
    _ "github.com/go-sql-driver/mysql"
    "log"
)

func ConnectDB() *sql.DB {
    dsn := "experiment:experiment@tcp(127.0.0.1:3306)/bikeshowroom"
    db, err := sql.Open("mysql", dsn)
    if err != nil {
        log.Fatal("Error connecting to the database:", err)
    }

    if err := db.Ping(); err != nil {
        log.Fatal("Unable to reach the database:", err)
    }

    log.Println("Database connection established.")
    return db
}