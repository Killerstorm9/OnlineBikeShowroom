package services

import (
	"OnlineBikeShowroom/models"
	"OnlineBikeShowroom/repositories"
)

type UserService struct {
	Repo *repositories.UserRepository
}

func (s *UserService) GetUserByUsername(username string) (*models.User, error) {
	return s.Repo.GetUserByUsername(username)
}

func (s *UserService) CreateUser(user models.User) error{
	return s.Repo.CreateUser(user)
}
