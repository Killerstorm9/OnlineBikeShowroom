package services

import (
	"OnlineBikeShowroom/models"
	"OnlineBikeShowroom/repositories"
)

type FeedbackService struct {
	Repo *repositories.FeedbackRepository
}

func (s *FeedbackService) CreateFeedback(feedback models.Feedback) error {
	return s.Repo.CreateFeedback(feedback)
}

func (s *FeedbackService) GetFeedbacksByUserID(userID string) ([]models.Feedback, error) {
	return s.Repo.GetFeedbacksByUserID(userID)
}