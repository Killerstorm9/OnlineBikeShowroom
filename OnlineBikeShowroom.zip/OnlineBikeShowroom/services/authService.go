package services

import (
	"OnlineBikeShowroom/models"
)

type AuthService struct {
	UserService *UserService
}

func (s *AuthService) Login(username,password string) (*models.User,bool) {
	user, err := s.UserService.GetUserByUsername(username)
	if err!=nil || user == nil {
		return nil,false
	}
	return user, user.Password==password
}