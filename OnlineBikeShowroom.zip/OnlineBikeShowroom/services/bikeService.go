package services

import (
	"OnlineBikeShowroom/models"
	"OnlineBikeShowroom/repositories"
)

type BikeService struct {
	Repo *repositories.BikeRepository
}

func (s *BikeService) GetAllBikes() ([]models.Bike, error) {
	return s.Repo.GetAllBikes()
}

func (s *BikeService) GetBikeByID(id string) (*models.Bike, error) {
	return s.Repo.GetBikeByID(id)
}

func (s *BikeService) CreateBike(bike models.Bike) error {
	return s.Repo.CreateBike(bike)
}

func (s *BikeService) UpdateBike(bike models.Bike) error {
	return s.Repo.UpdateBike(bike)
}

func (s *BikeService) DeleteBike(id int) error {
    return s.Repo.DeleteBike(id)
}
