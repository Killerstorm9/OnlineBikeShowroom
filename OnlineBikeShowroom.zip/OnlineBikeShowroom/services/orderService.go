package services

import (
	"OnlineBikeShowroom/models"
	"OnlineBikeShowroom/repositories"
)

type OrderService struct {
	Repo *repositories.OrderRepository
}

func (s *OrderService) CreateOrder(order models.Order) error {
	return s.Repo.CreateOrder(order)
}

func (s *OrderService) GetOrdersByUserID(userID string) ([]models.Order, error) {
	return s.Repo.GetOrdersByUserID(userID)
}



