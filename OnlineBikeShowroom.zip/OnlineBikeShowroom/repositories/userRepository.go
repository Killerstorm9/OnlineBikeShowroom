package repositories

import (
	"OnlineBikeShowroom/models"
	"database/sql"
	"log"
)

type UserRepository struct{
	DB *sql.DB
}

func (r *UserRepository) GetUserByUsername( username string) (*models.User, error) {
	var user models.User
	err:= r.DB.QueryRow("select id,username,password,name,contact_number,city,payment_method,wishlist from users where username=?", username).Scan(&user.ID,&user.Username,&user.Password,&user.Name,&user.ContactNumber,&user.City,&user.PaymentMethod,&user.Wishlist)
	if err != nil {
		if err== sql.ErrNoRows{
			return nil,nil
		}
		log.Println("Error in fetching user: ", err)
		return nil, err
	}
	return &user, nil
}

func (r *UserRepository) CreateUser(user models.User) error {
	query := "insert into users(username,password,name,contact_number,city,payment_method,wishlist) values (?,?,?,?,?,?,?)"
	_, err:= r.DB.Exec(query, user.Username, user.Password, user.Name,user.ContactNumber, user.City,user.PaymentMethod,user.Wishlist)
	if err!= nil {
		return err
	}
	return nil
}
