package repositories

import (
	"OnlineBikeShowroom/models"
	"database/sql"
)

type FeedbackRepository struct {
	DB *sql.DB
}

func (r *FeedbackRepository) CreateFeedback(feedback models.Feedback) error {
	query := "INSERT INTO feedback (user_id, bike_id, rating, comment) VALUES (?, ?, ?, ?)"
	_, err := r.DB.Exec(query, feedback.UserID, feedback.BikeID, feedback.Rating, feedback.Comment)
	if err != nil {
		return err
	}
	return nil
}

func (r *FeedbackRepository) GetFeedbacksByUserID(userID string) ([]models.Feedback, error) {
	query := "SELECT id, user_id, bike_id, rating, comment FROM feedback WHERE user_id = ?"
	rows, err := r.DB.Query(query, userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var feedbacks []models.Feedback
	for rows.Next() {
		var feedback models.Feedback
		err := rows.Scan(&feedback.ID, &feedback.UserID, &feedback.BikeID, &feedback.Rating, &feedback.Comment)
		if err != nil {
			return nil, err
		}
		feedbacks = append(feedbacks, feedback)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}

	return feedbacks, nil
}
