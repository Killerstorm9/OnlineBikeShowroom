package repositories

import (
	"OnlineBikeShowroom/models"
	"database/sql"
)

type OrderRepository struct {
	DB *sql.DB
}

func (r *OrderRepository) CreateOrder(order models.Order) error {
	query := "INSERT INTO orders (user_id, bike_id, payment_method) VALUES (?, ?, ?)"
	_, err := r.DB.Exec(query, order.UserID, order.BikeID, order.PaymentMethod)
	if err != nil {
		return err
	}
	return nil
}

func (r *OrderRepository) GetOrdersByUserID(userID string) ([]models.Order, error) {
	query := "SELECT id, user_id, bike_id, payment_method FROM orders WHERE user_id = ?"
	rows, err := r.DB.Query(query, userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var orders []models.Order
	for rows.Next() {
		var order models.Order
		err := rows.Scan(&order.ID, &order.UserID, &order.BikeID, &order.PaymentMethod)
		if err != nil {
			return nil, err
		}
		orders = append(orders, order)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}

	return orders, nil
}
