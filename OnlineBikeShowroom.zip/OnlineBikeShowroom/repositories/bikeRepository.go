package repositories

import (
    "OnlineBikeShowroom/models"
    "database/sql"
    "log"
    "fmt"
)

type BikeRepository struct {
    DB *sql.DB
}

func (r *BikeRepository) GetAllBikes() ([]models.Bike, error) {
    rows, err := r.DB.Query("SELECT id, name, engine_capacity, fuel_capacity, price FROM bikes")
    if err != nil {
        log.Println("Error fetching bikes:", err)
        return nil, err
    }
    defer rows.Close()

    var bikes []models.Bike
    for rows.Next() {
        var bike models.Bike
        if err := rows.Scan(&bike.ID, &bike.Name, &bike.EngineCapacity, &bike.FuelCapacity, &bike.Price); err != nil {
            return nil, err
        }
        bikes = append(bikes, bike)
    }
    return bikes, nil
}

func (r *BikeRepository) GetBikeByID(id string) (*models.Bike, error) {
	var bike models.Bike
	query := "SELECT id, name, engine_capacity, fuel_capacity, price FROM bikes WHERE id = ?"

	row := r.DB.QueryRow(query, id)
	err := row.Scan(&id, &bike.Name, &bike.EngineCapacity, &bike.FuelCapacity, &bike.Price)
	if err != nil {
		if err == sql.ErrNoRows {
			// No bike found for this id
			return nil, nil
		}
		return nil, fmt.Errorf("error fetching bike by id: %v", err)
	}

	return &bike, nil
}

func (r *BikeRepository) CreateBike(bike models.Bike) error {
    query := "INSERT INTO bikes (name, engine_capacity, fuel_capacity, price) VALUES (?, ?, ?, ?)"
    _, err := r.DB.Exec(query, bike.Name, bike.EngineCapacity, bike.FuelCapacity, bike.Price)
    if err != nil {
        return err
    }
    return nil
}

func (r *BikeRepository) UpdateBike(bike models.Bike) error {
    query := "UPDATE bikes SET name = ?, engine_capacity = ?, fuel_capacity = ?, price = ? WHERE id = ?"
    _, err := r.DB.Exec(query, bike.Name, bike.EngineCapacity, bike.FuelCapacity, bike.Price, bike.ID)
    if err != nil {
        return err
    }
    return nil
}

func (r *BikeRepository) DeleteBike(id int) error {
    query := "DELETE FROM bikes WHERE id = ?"
    _, err := r.DB.Exec(query, id)
    if err != nil {
        return err
    }
    return nil
}
