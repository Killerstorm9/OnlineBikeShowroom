package controllers

import (
    "OnlineBikeShowroom/models"
    "OnlineBikeShowroom/services"
    "net/http"
    "github.com/gin-gonic/gin"
)

type AuthController struct {
    AuthService *services.AuthService
}

func (c *AuthController) Login(ctx *gin.Context) {
    var input models.User
    if err := ctx.ShouldBindJSON(&input); err != nil {
        ctx.JSON(http.StatusBadRequest, gin.H{"error": "Invalid input"})
        return
    }
    user, valid := c.AuthService.Login(input.Username, input.Password)
    if !valid {
        ctx.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid credentials"})
        return
    }
    ctx.JSON(http.StatusOK, user)
}