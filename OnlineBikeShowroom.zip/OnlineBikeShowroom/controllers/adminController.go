package controllers

import (
	"OnlineBikeShowroom/models"
	"OnlineBikeShowroom/services"
	"net/http"
	"github.com/gin-gonic/gin"
	"strconv"
)

type AdminController struct {
	BikeService *services.BikeService
}

func (c *AdminController)ListBikes(ctx *gin.Context) {
	bikes, err := c.BikeService.GetAllBikes()
	if err!=nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch bikes"})
		return
	}
	ctx.JSON(http.StatusOK, bikes)
}

func (c *AdminController) AddBike(ctx *gin.Context) {
	var bike models.Bike
	if err:= ctx.ShouldBindJSON(&bike); err!=nil {
		ctx.JSON(http.StatusBadRequest, gin.H{"error":"Invalid input"})
		return
	}
	if err := c.BikeService.CreateBike(bike); err!=nil{
		ctx.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to add bike :( "})
		return
	}
	ctx.JSON(http.StatusCreated, bike)
}

func (c *AdminController) UpdateBike(ctx *gin.Context) {
	var bike models.Bike
	if err:= ctx.ShouldBindJSON(&bike); err!=nil {
		ctx.JSON(http.StatusBadRequest, gin.H{"error":"Invalid input"})
		return
	}
	if err := c.BikeService.UpdateBike(bike); err!=nil{
		ctx.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to add bike :( "})
		return
	}
	ctx.JSON(http.StatusCreated, bike)
}

func (c *AdminController) DeleteBike(ctx *gin.Context) {
    idParam := ctx.Param("id")
    id, err := strconv.Atoi(idParam)
    if err != nil {
        ctx.JSON(http.StatusBadRequest, gin.H{"error": "Invalid bike ID"})
        return
    }
    if err := c.BikeService.DeleteBike(id); err != nil {
        ctx.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to delete bike"})
        return
    }
    ctx.JSON(http.StatusNoContent, nil)
}
