package controllers

import (
	"OnlineBikeShowroom/models"
	"OnlineBikeShowroom/services"
	"net/http"
	"github.com/gin-gonic/gin"
)

type FeedbackController struct {
	FeedbackService *services.FeedbackService
}

func (c *FeedbackController) AddFeedback(ctx *gin.Context) {
	var feedback models.Feedback
	if err := ctx.ShouldBindJSON(&feedback); err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{"error": "Invalid input"})
		return
	}
	if err := c.FeedbackService.CreateFeedback(feedback); err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to add feedback"})
		return
	}
	ctx.JSON(http.StatusCreated, feedback)
}
