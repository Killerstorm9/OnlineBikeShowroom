package controllers

import (
	"OnlineBikeShowroom/models"
	"OnlineBikeShowroom/services"
	"net/http"

	"github.com/gin-gonic/gin"
)

type BuyerController struct {
	BikeService  *services.BikeService
	OrderService *services.OrderService
	FeedbackService *services.FeedbackService
}

func (c *BuyerController) GetBikeDetails(ctx *gin.Context) {
	id := ctx.Param("id")
	bike, err := c.BikeService.GetBikeByID(id)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch bike details"})
		return
	}
	if bike == nil {
		ctx.JSON(http.StatusNotFound, gin.H{"error": "Bike not found"})
		return
	}
	ctx.JSON(http.StatusOK, bike)
}

func (c *BuyerController) CreateOrder(ctx *gin.Context) {
	var order models.Order
	if err := ctx.ShouldBindJSON(&order); err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{"error": "Invalid order data"})
		return
	}

	err := c.OrderService.CreateOrder(order)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to place order"})
		return
	}

	ctx.JSON(http.StatusOK, gin.H{"message": "Order placed successfully"})
}

func (c *BuyerController) ViewOrders(ctx *gin.Context) {
	userID := ctx.Param("user_id")  

	orders, err := c.OrderService.GetOrdersByUserID(userID)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch orders"})
		return
	}

	ctx.JSON(http.StatusOK, orders)
}


func (c *BuyerController) CreateFeedback(ctx *gin.Context) {
	var feedback models.Feedback
	if err := ctx.ShouldBindJSON(&feedback); err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{"error": "Invalid feedback data"})
		return
	}

	err := c.FeedbackService.CreateFeedback(feedback)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to submit feedback"})
		return
	}

	ctx.JSON(http.StatusOK, gin.H{"message": "Feedback submitted successfully"})
}

func (c *BuyerController) ViewFeedbacks(ctx *gin.Context) {
	userID := ctx.Param("user_id")  

	feedbacks, err := c.FeedbackService.GetFeedbacksByUserID(userID)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch feedbacks"})
		return
	}

	ctx.JSON(http.StatusOK, feedbacks)
}
