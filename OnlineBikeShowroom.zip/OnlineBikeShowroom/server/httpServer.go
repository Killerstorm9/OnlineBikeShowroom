package server

import (
	"OnlineBikeShowroom/controllers"
	"github.com/gin-gonic/gin"
)

func StartServer(adminController *controllers.AdminController, buyerController *controllers.BuyerController, authController *controllers.AuthController) {
    router := gin.Default()

    // Admin 
    router.GET("/admin/bikes", adminController.ListBikes)
     /* 
     curl -X GET "http://localhost:8080/admin/bikes"  
     */
    router.POST("/admin/bikes", adminController.AddBike)
    /* 
     curl -X POST http://localhost:8080/admin/bikes -H "Content-Type: application/json" -d '{ "name": "Honda CBR", "engine_capacity": 200,"fuel_capacity": 12, "price": 350000 }' 
     */
    router.PUT("/admin/bikes/:id", adminController.UpdateBike)
    /* 
     curl -X PUT http://localhost:8080/admin/bikes/1 -H "Content-Type: application/json" -d '{ "name": "Yamaha R15 V3", "engine_capacity": 155,"fuel_capacity": 12, "price": 170000 }' 
     */
    router.DELETE("/admin/bikes/:id", adminController.DeleteBike)
    /* 
     curl -X DELETE "http://localhost:8080/admin/bikes/5" 
     */
    router.GET("/admin/bikes/:id", buyerController.GetBikeDetails)
    /* 
     curl -X GET "http://localhost:8080/admin/bikes/2" 
     */
    router.GET("/admin/:user_id/orders",buyerController.ViewOrders)
    /* 
     curl -X GET "http://localhost:8080/admin/1/orders" 
     */
    router.GET("/admin/:user_id/feedbacks",buyerController.ViewFeedbacks)
    /* 
     curl -X GET "http://localhost:8080/admin/1/feedbacks" 
     */

    // Buyer 
    router.GET("/bikes", adminController.ListBikes)
        /* 
     curl -X GET "http://localhost:8080/bikes" 
     */
    router.GET("/bikes/:id", buyerController.GetBikeDetails)
    /* 
     curl -X GET http://localhost:8080/bikes/4" 
     */
    router.POST("/orders", buyerController.CreateOrder)
    /* 
     curl -X POST http://localhost:8080/orders -H "Content-Type: application/json" -d '{"user_id": 1, "bike_id": 2,"payment_method": "credit_card"}' 
     */
    router.GET("/users/:user_id/orders", buyerController.ViewOrders)
        /* 
     curl -X GET "http://localhost:8080/users/1/orders" 
     */
    router.POST("/feedbacks",buyerController.CreateFeedback)
    /* 
    curl -X POST http://localhost:8080/feedbacks -H "Content-Type: application/json" -d '{
    "user_id": 1,
    "bike_id": 2,
    "rating": 5,"comment":"My dream bike!"
    }'
    */
    router.GET("/users/:user_id/feedbacks", buyerController.ViewFeedbacks)  
    /* 
     curl -X GET "http://localhost:8080/users/1/feedbacks" 
    */

    // Authentication - not working yet
    router.POST("/login", authController.Login)
    /* 
     curl -X POST http://localhost:8080/login -H "Content-Type: application/json" -d '{"username": "Administrator","password": "admin321"}' 
     */

    router.Run(":8080")
}
