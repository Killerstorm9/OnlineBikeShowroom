package main

import (
	"OnlineBikeShowroom/config"
	"OnlineBikeShowroom/controllers"
	"OnlineBikeShowroom/repositories"
	"OnlineBikeShowroom/server"
	"OnlineBikeShowroom/services"
)

func main() {
	db := config.ConnectDB()
	bikeRepo := &repositories.BikeRepository{DB: db}
	orderRepo := &repositories.OrderRepository{DB: db}  
	userRepo := &repositories.UserRepository{DB: db}
	feedbackRepo := &repositories.FeedbackRepository{DB: db}
	bikeService := &services.BikeService{Repo: bikeRepo}
	orderService := &services.OrderService{Repo: orderRepo}
	feedbackService := &services.FeedbackService{Repo: feedbackRepo} 
	userService := &services.UserService{Repo: userRepo}
	authService := &services.AuthService{UserService: userService}
	adminController := &controllers.AdminController{BikeService: bikeService}
	buyerController := &controllers.BuyerController{
		BikeService:  bikeService,
		OrderService: orderService,
		FeedbackService: feedbackService,
	}
	authController := &controllers.AuthController{AuthService: authService}

	server.StartServer(adminController, buyerController, authController)
}
