package models

type User struct {
    ID            int    `json:"id"`
    Username      string `json:"username"`
    Password      string `json:"password"`
    Name          string `json:"name"`
    ContactNumber string `json:"contact_number"`
    City          string `json:"city"`
    PaymentMethod string `json:"payment_method"`
    Wishlist      []int  `json:"wishlist"`
}