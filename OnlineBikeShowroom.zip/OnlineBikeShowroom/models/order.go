package models

type Order struct {
    ID            int    `json:"id"`
    UserID        int    `json:"user_id"`
    BikeID        int    `json:"bike_id"`
    PaymentMethod string `json:"payment_method"`
}