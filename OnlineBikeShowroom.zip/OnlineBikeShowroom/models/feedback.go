package models

type Feedback struct {
    ID       int    `json:"id"`
    UserID   int    `json:"user_id"`
    BikeID   int    `json:"bike_id"`
    Rating   int    `json:"rating"`
    Comment  string `json:"comment"`
}
