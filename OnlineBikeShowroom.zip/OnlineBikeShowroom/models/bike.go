package models

type Bike struct {
    ID             int     `json:"id"`
    Name           string  `json:"name"`
    EngineCapacity int     `json:"engine_capacity"`
    FuelCapacity   int     `json:"fuel_capacity"`
    Price          float64 `json:"price"`
}